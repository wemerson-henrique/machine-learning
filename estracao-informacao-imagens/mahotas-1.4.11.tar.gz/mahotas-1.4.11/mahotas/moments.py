import warnings
warnings.warn(
'''Use

from mahotas.features import moments
''', DeprecationWarning)

from mahotas.features.moments import *
