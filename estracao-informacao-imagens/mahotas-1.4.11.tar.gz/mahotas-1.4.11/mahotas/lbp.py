import warnings
warnings.warn(
'''Use

from mahotas.features import lbp
''', DeprecationWarning)

from mahotas.features.lbp import *
